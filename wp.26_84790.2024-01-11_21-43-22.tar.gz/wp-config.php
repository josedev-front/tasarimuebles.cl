<?php

//Begin Really Simple SSL session cookie settings
@ini_set('session.cookie_httponly', true);
@ini_set('session.cookie_secure', true);
@ini_set('session.use_only_cookies', true);
//END Really Simple SSL cookie settings
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'maryssty_wp16' );

/** Database username */
define( 'DB_USER', 'maryssty_wp16' );

/** Database password */
define( 'DB_PASSWORD', 'FV[S1908p-' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'yi6v8brbvyupoe3ih8fl6p7fesflfaqkg6c6lajgv8xdda7nydxrjzxjpnexs43i' );
define( 'SECURE_AUTH_KEY',  'h3xug38o7jskopbdrwxkubmmsgqbzcp4s6ffxixu4y4jtvpfzx4zguok8wmoi6mq' );
define( 'LOGGED_IN_KEY',    'zuxzbiqwfzemqhoeakndfqimu2bd3mvatlgvm7qcjnlhdbf81vplkzioxdjvhvvx' );
define( 'NONCE_KEY',        'arjnpnn76y5uyiqbica96hkn5xtmcvzxxldegalsdytucwnbswceauqlne5fcvcm' );
define( 'AUTH_SALT',        'lucyvtika9vazzhtlycrkmw3lfwusymgpycbgzim3mt29smtobmaa7cnu6idd8ia' );
define( 'SECURE_AUTH_SALT', '4wud4dbncgauivmjqg59m2wzug1rppscuvcorkia6vrkbnmncwxei39ez7z2q8iz' );
define( 'LOGGED_IN_SALT',   'z0blgsnbhh8anwhmakjodbtkmnbxa3ariibeg8fxdix1iguqe1dp9pdead2a0uud' );
define( 'NONCE_SALT',       'jncomxjydwewecgo1vrfemzammdrxn9nxz5qzdg2rrwdkeb6xxcpzanaf4yiwipw' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wpqp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
